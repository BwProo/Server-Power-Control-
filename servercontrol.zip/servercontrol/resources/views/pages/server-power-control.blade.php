<x-filament-panels::page>
    <div class="space-y-6">

        {{-- Action Bar --}}
        <div class="flex flex-wrap items-center gap-3 rounded-xl border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-700 dark:bg-gray-800">
            <span class="text-sm font-medium text-gray-600 dark:text-gray-400">
                {{ $this->selectedCount }} {{ trans('servercontrol::messages.servers_selected') }}
            </span>

            <div class="ml-auto flex flex-wrap gap-2">
                {{-- Start --}}
                <button
                    wire:click="startSelected"
                    wire:loading.attr="disabled"
                    class="inline-flex items-center gap-1.5 rounded-lg bg-green-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-green-500 disabled:opacity-50"
                >
                    ▶ {{ trans('servercontrol::messages.start_selected') }}
                </button>

                {{-- Restart --}}
                <button
                    wire:click="restartSelected"
                    wire:loading.attr="disabled"
                    class="inline-flex items-center gap-1.5 rounded-lg bg-yellow-500 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-yellow-400 disabled:opacity-50"
                >
                    ↺ {{ trans('servercontrol::messages.restart_selected') }}
                </button>

                {{-- Stop --}}
                <button
                    wire:click="stopSelected"
                    wire:loading.attr="disabled"
                    class="inline-flex items-center gap-1.5 rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-red-500 disabled:opacity-50"
                >
                    ■ {{ trans('servercontrol::messages.stop_selected') }}
                </button>

                {{-- Kill --}}
                <button
                    wire:click="killSelected"
                    wire:loading.attr="disabled"
                    class="inline-flex items-center gap-1.5 rounded-lg bg-gray-700 px-4 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-gray-600 disabled:opacity-50"
                    onclick="return confirm('{{ trans('servercontrol::messages.kill_confirm') }}')"
                >
                    ✕ {{ trans('servercontrol::messages.kill_selected') }}
                </button>
            </div>
        </div>

        {{-- Server Table --}}
        <div class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm dark:border-gray-700 dark:bg-gray-800">
            <table class="w-full text-left text-sm">
                <thead class="border-b border-gray-200 bg-gray-50 dark:border-gray-700 dark:bg-gray-900">
                    <tr>
                        <th class="w-10 px-4 py-3">
                            <input
                                type="checkbox"
                                wire:model.live="selectAll"
                                wire:change="toggleSelectAll"
                                class="rounded border-gray-300 text-primary-600 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700"
                            />
                        </th>
                        <th class="px-4 py-3 font-semibold text-gray-700 dark:text-gray-300">
                            {{ trans('servercontrol::messages.column_name') }}
                        </th>
                        <th class="px-4 py-3 font-semibold text-gray-700 dark:text-gray-300">
                            {{ trans('servercontrol::messages.column_owner') }}
                        </th>
                        <th class="px-4 py-3 font-semibold text-gray-700 dark:text-gray-300">
                            {{ trans('servercontrol::messages.column_node') }}
                        </th>
                        <th class="px-4 py-3 font-semibold text-gray-700 dark:text-gray-300">
                            {{ trans('servercontrol::messages.column_uuid') }}
                        </th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100 dark:divide-gray-700">
                    @forelse ($this->servers as $server)
                        <tr
                            wire:key="server-{{ $server->id }}"
                            class="transition hover:bg-gray-50 dark:hover:bg-gray-700/50 {{ in_array($server->id, $selectedServers) ? 'bg-primary-50 dark:bg-primary-900/20' : '' }}"
                        >
                            <td class="px-4 py-3">
                                <input
                                    type="checkbox"
                                    wire:model.live="selectedServers"
                                    value="{{ $server->id }}"
                                    class="rounded border-gray-300 text-primary-600 focus:ring-primary-500 dark:border-gray-600 dark:bg-gray-700"
                                />
                            </td>
                            <td class="px-4 py-3 font-medium text-gray-900 dark:text-white">
                                {{ $server->name }}
                            </td>
                            <td class="px-4 py-3 text-gray-600 dark:text-gray-400">
                                {{ $server->user->email ?? '—' }}
                            </td>
                            <td class="px-4 py-3 text-gray-600 dark:text-gray-400">
                                {{ $server->node->name ?? '—' }}
                            </td>
                            <td class="px-4 py-3 font-mono text-xs text-gray-400 dark:text-gray-500">
                                {{ substr($server->uuid, 0, 8) }}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="px-4 py-8 text-center text-gray-500 dark:text-gray-400">
                                {{ trans('servercontrol::messages.no_servers') }}
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

    </div>
</x-filament-panels::page>
