<?php

return [
    'servers_selected'     => 'server(s) selected',
    'no_servers_selected'  => 'No servers selected.',
    'no_servers'           => 'No servers found.',

    // Buttons
    'start_selected'   => 'Start Selected',
    'stop_selected'    => 'Stop Selected',
    'restart_selected' => 'Restart Selected',
    'kill_selected'    => 'Kill Selected',

    // Notifications
    'start_sent'   => ':count server(s) received the start signal.',
    'stop_sent'    => ':count server(s) received the stop signal.',
    'restart_sent' => ':count server(s) received the restart signal.',
    'kill_sent'    => ':count server(s) were forcefully killed.',

    // Confirm
    'kill_confirm' => 'This will forcefully kill the selected servers. Are you sure?',

    // Table columns
    'column_name'  => 'Server Name',
    'column_owner' => 'Owner',
    'column_node'  => 'Node',
    'column_uuid'  => 'UUID',
];
