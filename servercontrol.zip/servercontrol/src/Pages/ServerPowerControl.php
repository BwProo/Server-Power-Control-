<?php

namespace BwProo\ServerControl\Pages;

use App\Models\Server;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Illuminate\Support\Facades\Log;

class ServerPowerControl extends Page
{
    protected static ?string $title = 'Server Power Control';

    protected string $view = 'servercontrol::pages.server-power-control';

    /** @var array<int> */
    public array $selectedServers = [];

    public bool $selectAll = false;

    public function mount(): void
    {
        $this->selectedServers = [];
        $this->selectAll = false;
    }

    public function toggleSelectAll(): void
    {
        if ($this->selectAll) {
            $this->selectedServers = Server::query()->pluck('id')->map(fn ($id) => (int) $id)->toArray();
        } else {
            $this->selectedServers = [];
        }
    }

    private function sendPowerAction(string $action): int
    {
        if (empty($this->selectedServers)) {
            return 0;
        }

        $servers = Server::query()->with('node')->whereIn('id', $this->selectedServers)->get();
        $count = 0;

        foreach ($servers as $server) {
            try {
                $node = $server->node;
                if (! $node) {
                    continue;
                }

                $scheme = $node->scheme ?? 'https';
                $url = "{$scheme}://{$node->fqdn}:{$node->daemon_listen}/api/servers/{$server->uuid}/power";

                \Illuminate\Support\Facades\Http::withHeaders([
                    'Authorization' => 'Bearer ' . $node->daemon_token,
                    'Content-Type'  => 'application/json',
                    'Accept'        => 'application/json',
                ])->timeout(10)->post($url, ['action' => $action]);

                $count++;
            } catch (\Throwable $e) {
                Log::error('ServerControl: power action failed', [
                    'server' => $server->uuid,
                    'action' => $action,
                    'error'  => $e->getMessage(),
                ]);
            }
        }

        return $count;
    }

    public function startSelected(): void
    {
        if (empty($this->selectedServers)) {
            Notification::make()
                ->title(trans('servercontrol::messages.no_servers_selected'))
                ->icon('tabler-alert-circle')
                ->warning()
                ->send();
            return;
        }
        $count = $this->sendPowerAction('start');
        Notification::make()
            ->title(trans('servercontrol::messages.start_sent', ['count' => $count]))
            ->icon('tabler-player-play')
            ->success()
            ->send();
        $this->selectedServers = [];
        $this->selectAll = false;
    }

    public function stopSelected(): void
    {
        if (empty($this->selectedServers)) {
            Notification::make()
                ->title(trans('servercontrol::messages.no_servers_selected'))
                ->icon('tabler-alert-circle')
                ->warning()
                ->send();
            return;
        }
        $count = $this->sendPowerAction('stop');
        Notification::make()
            ->title(trans('servercontrol::messages.stop_sent', ['count' => $count]))
            ->icon('tabler-player-stop')
            ->success()
            ->send();
        $this->selectedServers = [];
        $this->selectAll = false;
    }

    public function killSelected(): void
    {
        if (empty($this->selectedServers)) {
            Notification::make()
                ->title(trans('servercontrol::messages.no_servers_selected'))
                ->icon('tabler-alert-circle')
                ->warning()
                ->send();
            return;
        }
        $count = $this->sendPowerAction('kill');
        Notification::make()
            ->title(trans('servercontrol::messages.kill_sent', ['count' => $count]))
            ->icon('tabler-skull')
            ->danger()
            ->send();
        $this->selectedServers = [];
        $this->selectAll = false;
    }

    public function restartSelected(): void
    {
        if (empty($this->selectedServers)) {
            Notification::make()
                ->title(trans('servercontrol::messages.no_servers_selected'))
                ->icon('tabler-alert-circle')
                ->warning()
                ->send();
            return;
        }
        $count = $this->sendPowerAction('restart');
        Notification::make()
            ->title(trans('servercontrol::messages.restart_sent', ['count' => $count]))
            ->icon('tabler-refresh')
            ->success()
            ->send();
        $this->selectedServers = [];
        $this->selectAll = false;
    }

    public function getServersProperty()
    {
        return Server::query()
            ->with(['node', 'user'])
            ->orderBy('name')
            ->get();
    }

    public function getSelectedCountProperty(): int
    {
        return count($this->selectedServers);
    }
}
