<?php

namespace BwProo\ServerControl;

use App\Contracts\Plugins\HasPluginSettings;
use BwProo\ServerControl\Pages\ServerPowerControl;
use Filament\Contracts\Plugin as FilamentPlugin;
use Filament\Panel;

class ServerControlPlugin implements FilamentPlugin
{
    public function getId(): string
    {
        return 'servercontrol';
    }

    public function register(Panel $panel): void
    {
        $panel->pages([
            ServerPowerControl::class,
        ]);
    }

    public function boot(Panel $panel): void
    {
    }
}
