<?php

namespace BwProo\ServerControl\Providers;

use Illuminate\Support\ServiceProvider;

class ServerControlPluginProvider extends ServiceProvider
{
    public function register(): void
    {
    }

    public function boot(): void
    {
        $this->loadTranslationsFrom(__DIR__ . '/../../lang', 'servercontrol');
        $this->loadViewsFrom(__DIR__ . '/../../resources/views', 'servercontrol');
    }
}
